function abrir() {
    document.getElementById("div").style.height = "100%";
}

function cerrar() {
        document.getElementById("div").style.height = "0%";
}
